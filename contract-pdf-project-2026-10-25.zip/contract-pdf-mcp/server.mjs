import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {createInterface} from 'node:readline';
import {createHash,randomUUID} from 'node:crypto';
const run=promisify(execFile),root=path.dirname(fileURLToPath(import.meta.url));
const configPath=process.env.CONTRACT_PDF_CONFIG||path.join(root,'runtime.json');
let settings,activeCapture=false;
const pending=new Map();
const tools=[
{"name":"upload_pdf_file","description":"사용자가 지정한 로컬 PDF 파일을 비공개 임시 보관함에 업로드합니다. 새 화면 캡처 없이 기존 PDF를 올리는 도구입니다. 사용자가 지정하거나 이 작업에서 생성한 PDF 경로만 사용하세요.","inputSchema":{"type":"object","properties":{"pdf_path":{"type":"string"}},"required":["pdf_path"],"additionalProperties":false},"annotations":{"readOnlyHint":false,"destructiveHint":false}},
 {name:'capture_and_upload_pdf',description:'사용자가 "42000 화면 캡처해서 PDF로 임시페이지에 올려줘"라고 요청할 때 사용합니다. 실행 중인 계약서 통합단말의 42000 화면에서 현재 조회된 모든 행(스크롤 밖 포함)을 PDF로 생성하고 비공개 임시 보관함에 첨부합니다. 임의 예제 데이터를 생성하거나 조회 조건을 변경하지 않습니다. 앱이 실행되지 않았으면 오류를 반환합니다.',inputSchema:{type:'object',properties:{screen_number:{type:'integer',enum:[42000],default:42000}},additionalProperties:false},annotations:{readOnlyHint:false,destructiveHint:false,idempotentHint:false,openWorldHint:true}},
 {name:'list_uploaded_pdfs',description:'임시페이지에 업로드된 PDF의 이름, 조회 건수, 업로드 시각과 다운로드 URL을 확인합니다.',inputSchema:{type:'object',properties:{cursor:{type:'string'}},additionalProperties:false},annotations:{readOnlyHint:true}},
 {name:'download_uploaded_pdf',description:'임시페이지에 올라간 PDF를 이 PC의 Downloads 폴더(연동 프로그램 내부)에 다시 다운로드하고 SHA256을 검증합니다.',inputSchema:{type:'object',properties:{id:{type:'string'}},required:['id'],additionalProperties:false},annotations:{readOnlyHint:false,destructiveHint:false}}
];
async function config(){
 if(settings)return settings;
 const c=JSON.parse(await fs.readFile(configPath,'utf8'));
 const site=new URL(c.siteUrl);
 if(site.protocol!=='https:'&&!(process.env.CONTRACT_PDF_TEST==='1'&&site.hostname==='127.0.0.1'))throw Error('보관함 주소는 HTTPS여야 합니다.');
 if(!path.isAbsolute(c.terminalExe))throw Error('통합단말 실행 파일의 절대 경로가 필요합니다.');
 settings=c;return c;
}
async function request(relative,options={},signal){
 const c=await config();
 const response=await fetch(new URL(relative,c.siteUrl),{...options,redirect:'error',signal,headers:{...(c.serviceToken?{'OAI-Sites-Authorization':'Bearer '+c.serviceToken}:{}),...options.headers}});
 if(!response.ok){let message;try{message=(await response.json()).error;}catch{}throw Error(message||'보관함 요청 실패 ('+response.status+'). 로그인/연결 설정을 확인하세요.');}
 return response;
}
async function data(relative,options,signal){
 const response=await request(relative,options,signal);
 if(!(response.headers.get('content-type')||'').includes('application/json'))throw Error('보관함 인증이 필요합니다. 연결 설정을 확인하세요.');
 return response.json();
}
async function captureUpload(args,signal){
 if(args.screen_number!==undefined&&args.screen_number!==42000)throw Error('42000 화면만 지원합니다.');
 if(activeCapture)throw Error('다른 캡처를 처리하고 있습니다. 잠시 후 다시 요청하세요.');
 activeCapture=true;
 try{
  const c=await config();let stdout;
  try{({stdout}=await run(path.join(path.dirname(c.terminalExe),'ContractTerminal.Capture.exe'),[],{windowsHide:true,encoding:'utf8',timeout:100000,maxBuffer:1024*1024}));}
  catch(error){if(error.stdout){try{throw Error(JSON.parse(error.stdout.replace(/^\uFEFF/,'').trim()).error);}catch(parsed){if(parsed instanceof SyntaxError)throw Error('통합단말을 실행한 뒤 다시 요청하세요.');throw parsed;}}throw Error('통합단말 실행 파일을 찾거나 연결할 수 없습니다.');}
  const capture=JSON.parse(stdout.replace(/^\uFEFF/,'').trim());if(!capture.ok)throw Error(capture.error);
  const exportRoot=path.resolve(path.dirname(c.terminalExe),'Exports')+path.sep;
  if(!path.resolve(capture.path).toLowerCase().startsWith(exportRoot.toLowerCase()))throw Error('캡처 결과 경로가 올바르지 않습니다.');
  signal.throwIfAborted();
  const bytes=await fs.readFile(capture.path);if(bytes.length>20*1024*1024)throw Error('생성된 PDF가 20MB를 초과했습니다. PDF는 로컬에 보관되어 있습니다.');
  const uploadId=randomUUID();
  const item=await data('/api/files',{method:'POST',headers:{'content-type':'application/pdf','x-file-name':encodeURIComponent(capture.filename),'x-upload-source':'42000 MCP','x-row-count':String(capture.rows),'x-upload-id':uploadId},body:bytes},signal);
  const hash=createHash('sha256').update(bytes).digest('hex');if(item.sha256!==hash)throw Error('업로드 파일 검증에 실패했습니다.');
  return {...item,localPath:capture.path,pageUrl:c.siteUrl,message:'42000 화면의 조회 결과 '+capture.rows+'건을 PDF로 생성하여 업로드했습니다.'};
 }finally{activeCapture=false;}
}
async function uploadExisting(args,signal){
 if(typeof args.pdf_path!=='string'||!path.isAbsolute(args.pdf_path))throw Error('사용자가 지정한 PDF의 절대 경로가 필요합니다.');
 if(path.extname(args.pdf_path).toLowerCase()!=='.pdf')throw Error('PDF 파일만 업로드할 수 있습니다.');
 const info=await fs.stat(args.pdf_path);if(!info.isFile()||info.size<1||info.size>20*1024*1024)throw Error('20MB 이하의 PDF 파일만 업로드할 수 있습니다.');
 const bytes=await fs.readFile(args.pdf_path);
 if(bytes.subarray(0,5).toString()!=='%PDF-')throw Error('정상적인 PDF 파일이 아닙니다.');
 const item=await data('/api/files',{method:'POST',headers:{'content-type':'application/pdf','x-file-name':encodeURIComponent(path.basename(args.pdf_path)),'x-upload-id':randomUUID()},body:bytes},signal);
 if(item.sha256!==createHash('sha256').update(bytes).digest('hex'))throw Error('업로드 파일 검증에 실패했습니다.');
 return {...item,pageUrl:(await config()).siteUrl,localPath:args.pdf_path};
}

async function download(args,signal){
 if(!/^[a-f0-9-]{36}$/.test(args.id||''))throw Error('올바른 PDF ID를 입력하세요.');
 let cursor,found;do{const list=await data('/api/files'+(cursor?'?cursor='+encodeURIComponent(cursor):''),{},signal);found=list.files.find(f=>f.id===args.id);cursor=list.cursor;}while(cursor&&!found);
 if(!found)throw Error('보관함에서 PDF를 찾지 못했습니다.');
 const response=await request('/api/files/'+args.id+'/download',{},signal);
 const bytes=Buffer.from(await response.arrayBuffer());
 const hash=createHash('sha256').update(bytes).digest('hex');if(hash!==found.sha256)throw Error('다운로드 파일 해시가 원본과 다릅니다.');
 const folder=path.join(root,'Downloads');await fs.mkdir(folder,{recursive:true});
 const filename=found.id+'_'+path.basename(found.name).replace(/[<>:"/\\|?*\x00-\x1f]/g,'_');
 const destination=path.join(folder,filename);await fs.writeFile(destination,bytes);
 return {...found,localPath:destination,verified:true};
}
async function dispatch(call){
 if(call.method==='notifications/cancelled'){pending.get(call.params?.requestId)?.abort();return;}
 if(!('id' in call))return;
 let result;
 if(call.method==='initialize')result={protocolVersion:['2026-07-28','2025-06-18','2024-11-05'].includes(call.params?.protocolVersion)?call.params.protocolVersion:'2025-06-18',capabilities:{tools:{}},serverInfo:{name:'contract-pdf',version:'1.0.0'},instructions:'사용자가 현재 42000 화면을 PDF로 임시페이지에 올려달라고 하면 capture_and_upload_pdf를 호출하세요. 도구가 반환한 실제 결과와 URL만 보고하세요.'};
 else if(call.method==='server/discover')result={supportedVersions:['2026-07-28','2025-06-18','2024-11-05'],capabilities:{tools:{}},serverInfo:{name:'contract-pdf',version:'1.0.0'}};
 else if(call.method==='ping')result={};
 else if(call.method==='tools/list')result={tools};
 else if(call.method==='tools/call'){
  const controller=new AbortController();pending.set(call.id,controller);
  const timeout=setTimeout(()=>controller.abort(),120000);
  try{
   const a=call.params.arguments||{};let output;
   if(call.params.name==='capture_and_upload_pdf')output=await captureUpload(a,controller.signal);
   else if(call.params.name==='list_uploaded_pdfs')output=await data('/api/files'+(a.cursor?'?cursor='+encodeURIComponent(a.cursor):''),{},controller.signal);
   else if(call.params.name==='upload_pdf_file')output=await uploadExisting(a,controller.signal);
   else if(call.params.name==='download_uploaded_pdf')output=await download(a,controller.signal);
   else throw Error('알 수 없는 도구입니다.');
   result={content:[{type:'text',text:JSON.stringify(output)}],structuredContent:output};
  }catch(error){result={isError:true,content:[{type:'text',text:error.name==='AbortError'?'요청이 취소되었거나 시간이 초과되었습니다.':error.message}]};}
  finally{clearTimeout(timeout);pending.delete(call.id);}
 }else return {jsonrpc:'2.0',id:call.id,error:{code:-32601,message:'Method not found'}};
 return {jsonrpc:'2.0',id:call.id,result};
}
const lines=createInterface({input:process.stdin,crlfDelay:Infinity});
lines.on('line',async line=>{
 if(!line.trim())return;
 try{
  if(line.length>1024*1024)throw Error('Message too large');
  const call=JSON.parse(line);if(call.jsonrpc!=='2.0')throw Error('Invalid JSON-RPC');
  const reply=await dispatch(call);if(reply)process.stdout.write(JSON.stringify(reply)+'\n');
 }catch{process.stdout.write(JSON.stringify({jsonrpc:'2.0',id:null,error:{code:-32700,message:'Invalid JSON-RPC message'}})+'\n');}
});
