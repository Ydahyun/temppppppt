# 계약서 통합단말 + PDF 임시 보관함 + MCP
작업 중간 결과 묶음 — 2026-10-25

## 현재 상태
- PDF 임시 보관함 배포 완료:
  https://contract-pdf-inbox-42000.frostywren.chatgpt.site/
- 소유자 전용 페이지이며 로그인 상태에 따라 인증이 필요합니다.
- PDF 수동 업로드, 목록 조회, 다운로드 API를 실제 서버에서 검증했습니다.
- 로컬 MCP 표준 입출력 호출로 기존 PDF 업로드 → 목록 조회 → 다운로드를 검증했고 원본/다운로드 SHA256 일치를 확인했습니다.
- 브라우저 UI 업로드도 확인했습니다. 자동화 브라우저의 다운로드 저장은 취소되어 UI 다운로드 완료 검증은 되지 않았습니다. 다운로드 API와 MCP 다운로드는 검증했습니다.
- 새 데스크톱 프로그램에는 현재 42000 조회 결과를 PDF로 내보내는 연결 코드를 추가했습니다.
- 새 EXE는 이 PC의 Windows 애플리케이션 제어 정책으로 차단되었습니다. 사용자도 동일한 차단을 확인했습니다.
- 따라서 새 데스크톱 버전의 캡처 → MCP → 업로드 전체 연결은 아직 검증하지 못했습니다.
- 로컬 MCP 서버 파일과 연결용 비공개 설정은 이 PC에 준비했지만 Codex 설정 파일에는 아직 등록하지 않았습니다.
- 보관함에서 제공하는 원격 MCP 플러그인은 배포되었으며 설치된 것으로 확인됐습니다. 현재 채팅에 도구가 나타나는지는 별도 확인이 필요합니다.

## 폴더 구성
1. desktop-current/
   현재 작업 중인 Windows 데스크톱 소스, 실행 파일, WebView2 DLL, 웹 UI.
   app/ContractTerminal.exe: 화면 프로그램.
   app/ContractTerminal.Capture.exe: MCP용 캡처 요청 클라이언트.
   src/: C# 소스.
   build.ps1: 실행 파일과 설치 파일을 다시 만드는 스크립트.
   주의: 새 실행 파일은 이 PC에서 차단되므로 동작 보장된 배포본이 아닙니다.

2. desktop-previous/
   MCP 연결 추가 전의 기존 설치 파일.
   앞선 작업에서 독립 실행과 120건 PDF 출력이 검증된 버전입니다.
   현재 PC에서 다시 실행 가능한지는 Windows 정책에 따라 달라질 수 있습니다.

3. web-original/
   최초 HTML/CSS/JavaScript 버전.
   index.html을 브라우저에서 직접 열거나 node server.cjs로 실행할 수 있습니다.
   원래의 100/200/300/42000 화면과 Ctrl+F3 출력 흐름을 포함합니다.

4. pdf-inbox-site/
   배포된 임시 보관함의 서버/화면 소스입니다.
   worker/index.js: UI, PDF 업로드/다운로드 API, 사이트 MCP 도구.
   .openai/hosting.json: 사이트 ID와 저장소 선언.
   scripts/build.mjs: Windows에서도 실행 가능한 빌드.
   파일 저장에는 Sites가 제공하는 R2 BUCKET 바인딩이 필요합니다.
   브라우저 localStorage에 저장하는 데모가 아니라 서버 파일 저장 방식입니다.

5. contract-pdf-mcp/
   server.mjs: Node.js 기반 로컬 MCP 서버. 외부 npm 패키지가 필요 없습니다.
   runtime.example.json: 비밀값이 제거된 설정 예시.
   codex-config.example.toml: 수동 등록할 MCP 설정 예시.
   실제 인증 토큰, runtime.json, 개인 Codex 설정은 ZIP에 포함하지 않았습니다.

6. examples/
   가상 계약 120건 출력 PDF와 구현 화면 이미지.

## MCP 도구
- capture_and_upload_pdf: 실행 중인 42000 화면 → 전체 조회 데이터 PDF → 임시 보관함 업로드
  현재 새 EXE 차단 때문에 이 PC에서는 사용 불가 / 전체 연결 미검증.
- upload_pdf_file: 이미 저장된 로컬 PDF를 업로드. 실제 MCP 호출 검증 완료.
- list_uploaded_pdfs: 업로드 목록과 다운로드 URL 조회. 검증 완료.
- download_uploaded_pdf: 업로드된 파일을 로컬 Downloads에 저장하고 SHA256 확인. 검증 완료.

## 자연어 사용 목표
MCP 등록과 데스크톱 실행 문제가 해결된 뒤 AI 채팅에서:
"42000 화면 캡처해서 PDF로 임시페이지에 올려줘."

현재 검증된 기존 PDF 업로드 요청:
"이 PDF를 임시페이지에 올려줘: C:\\경로\\문서.pdf"

위 문장을 일반 웹페이지 입력란에 입력하는 기능은 없습니다.
MCP를 연결한 AI 채팅이 도구를 호출하는 방식입니다.

## 로컬 MCP 준비
Node.js 18 이상이 필요하며 이 PC에는 Node.js가 설치되어 있습니다.
runtime.example.json을 runtime.json으로 복사하고,
siteUrl / serviceToken / terminalExe를 올바르게 설정합니다.
인증 토큰은 소스 저장소나 공유 ZIP에 넣지 마세요.
이 PC에 준비된 비공개 설정은 별도 설치 위치에 있으며 이 ZIP에는 복사하지 않았습니다.

Codex 설정에 codex-config.example.toml 내용을 실제 설치 경로에 맞춰 추가한 후
앱을 다시 시작하거나 새 채팅에서 MCP 연결 상태를 확인합니다.
도구는 MCP 클라이언트로 실행해야 하며 server.mjs를 단독 실행하면 표준 입력 요청을 기다립니다.

## 데스크톱 빌드
Windows .NET Framework 4.x의 C# 컴파일러가 있는 PC에서:
  cd desktop-current
  .\build.ps1

WebView2 Runtime은 별도로 설치되어 있어야 합니다.
코드 서명 인증서는 포함하지 않았습니다.
Windows 정책이 실행을 차단하는 경우 이 묶음은 정책 우회 방법을 제공하지 않습니다.
실행이 허용된 개발/배포 환경 또는 조직의 승인된 코드 서명·배포 절차가 필요합니다.

## 제외한 항목
- 실제 사이트 인증 토큰 및 Git 인증 정보
- 개인 Codex config.toml
- WebView2 사용자 프로필/캐시
- MCP 다운로드 테스트 파일, 임시 통신 파일
- Git 저장소 내부 데이터

이 문서의 상태 설명은 하위 폴더에 남아 있는 이전 버전 안내보다 우선합니다.
