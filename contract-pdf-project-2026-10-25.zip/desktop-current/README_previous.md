# 계약서 통합단말 — Windows 데스크톱 버전

## 설치 및 실행
1. ContractTerminal-Setup.exe를 실행합니다.
2. 설치 안내에서 확인을 누릅니다.
3. 설치가 끝나면 바탕화면의 **계약서 통합단말** 아이콘을 더블클릭합니다.

별도 브라우저, localhost 서버, Node.js, VS Code를 실행할 필요가 없습니다.
프로그램은 Windows 네이티브 창 안에서 WebView2로 화면을 표시합니다. 내부 terminal.internal 주소는 로컬 파일 매핑이며 서버나 외부 웹사이트가 아닙니다.

기본 설치 위치: %LOCALAPPDATA%\Programs\ContractTerminal
사용자 프로필/캐시: %LOCALAPPDATA%\ContractTerminal\WebView2
설치 범위: 현재 Windows 사용자. 관리자 권한 불필요.

설치 없이 실행하려면 소스 ZIP의 app 폴더를 통째로 압축 해제한 뒤 ContractTerminal.exe를 실행하세요.
EXE만 따로 옮기면 실행되지 않습니다. 함께 제공되는 DLL, www 폴더가 필요합니다.

## 사용
- 화면번호 100 / 200 / 300 / 42000 입력 → 검색.
- 100~300은 빈 화면, 42000은 계약서 조회 화면.
- 기본 데이터 0건. 테스트 데이터 버튼으로 120건 등 생성 → 조회.
- Ctrl+F3 → 복합기 / 텍스트(현재 화면 출력) → 확인 → 안내 확인.
- 독립 출력 창과 인쇄 미리보기가 열립니다.
- 인쇄 대상에서 PDF로 저장 또는 실제 프린터를 선택합니다.
- 출력 창의 **PDF 파일로 저장** 버튼으로도 저장할 수 있습니다. 이 버튼은 저장할 위치를 선택하면 A4 가로 PDF를 직접 생성합니다.
- 데이터 전체를 여러 페이지로 나누며 가로/세로 스크롤로 가려진 행과 열도 포함합니다.
- 원본 안내문의 센터 관리 문구는 화면 재현용입니다. 실제 센터 전송, MCP 업로드, DB 연동 기능은 없습니다.

## 실행 환경
Windows 10/11 x64, .NET Framework 4.6.2 이상, Microsoft Edge WebView2 Runtime.
현재 PC에서 .NET과 WebView2 Runtime을 확인하고 실행 검증했습니다.
다른 PC에 WebView2가 없으면 Microsoft 공식 Runtime을 설치해야 합니다.
공식 다운로드: https://developer.microsoft.com/microsoft-edge/webview2/
공식 배포 설명: https://learn.microsoft.com/microsoft-edge/webview2/concepts/distribution

이 테스트용 실행 파일에는 상용 코드 서명 인증서를 적용하지 않았습니다. 다른 PC에서는 Windows가 게시자를 확인하지 못했다고 표시할 수 있습니다. 조직 배포 시에는 코드 서명 및 배포 정책을 적용하세요.

## 업데이트 / 제거
- 업데이트: 프로그램을 종료한 다음 새 Setup.exe를 실행합니다. 동일 설치 위치의 프로그램 파일을 갱신합니다.
- 제거: 프로그램을 종료하고 위 설치 폴더와 바탕화면 바로가기를 삭제합니다.
- 캐시도 제거하려면 위 사용자 프로필/캐시 폴더를 삭제합니다.
- 이 간단 설치기는 Windows 앱 제거 목록에 항목을 등록하지 않습니다.

## 소스 수정 및 빌드
VS Code에서 terminal-desktop 폴더를 엽니다.
- app/www/index.html: 공통 UI 및 대화상자
- app/www/styles.css: 화면 스타일
- app/www/app.js: 화면 전환, 조회, 인쇄 스냅샷
- src/Program.cs: Windows 창, WebView2, 인쇄 창, PDF 저장
- src/Setup.cs: 설치 파일 배포와 바탕화면 바로가기 생성
- src/app.manifest: DPI 및 실행 권한 설정
- build.ps1: EXE와 설치 파일 빌드

화면 파일을 수정한 뒤에는 프로그램을 종료하고 다시 실행합니다.
설치된 프로그램을 갱신하려면 빌드 후 새 설치 파일을 실행하세요.

PowerShell 터미널:
    .\build.ps1

빌드에는 Windows .NET Framework의 csc.exe가 필요합니다. 이번에 사용한 DLL은 app 폴더에 포함되어 있어 NuGet 복원이 필요 없습니다.
SDK: Microsoft.Web.WebView2 1.0.4258.31
원본 패키지: https://www.nuget.org/packages/Microsoft.Web.WebView2/1.0.4258.31
동봉 LICENSE.txt 및 NOTICE.txt 참고.

## 검증
실제 WebView2 Runtime에서 네이티브 앱 초기화, 4개 화면 전환, 조회, PDF 생성을 검증했습니다.
- 120건 PDF: 6페이지, 120개 관리번호 모두 포함.
- 승인 상태 조건 조회: 40건 PDF, 선택한 조건값 포함.
- 별도 임시 경로 설치, 파일 추출, 바탕화면용 .lnk 생성 성공.
실제 물리 프린터로 종이를 출력하지는 않았습니다.

## 이 PC에 완료한 설치
현재 PC는 실행 환경의 AppData 쓰기 제한으로 다음 경로에 설치했습니다.
C:\Users\User\Documents\Codex\Applications\ContractTerminal
바탕화면의 '계약서 통합단말' 바로가기가 이 폴더의 ContractTerminal.exe를 실행합니다.
이 폴더를 이동하거나 삭제하면 바로가기가 작동하지 않으므로 그대로 유지해 주세요.
위의 기본 AppData 설치 위치는 다른 PC에서 Setup.exe를 일반 실행할 때 적용됩니다.
