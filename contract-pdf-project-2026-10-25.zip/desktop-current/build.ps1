$ErrorActionPreference='Stop'
Push-Location $PSScriptRoot
try {
 $compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
 & $compiler /nologo /target:winexe /platform:x64 /out:app\ContractTerminal.exe /win32icon:app\terminal.ico /win32manifest:src\app.manifest /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.Web.Extensions.dll /reference:app\Microsoft.Web.WebView2.Core.dll /reference:app\Microsoft.Web.WebView2.WinForms.dll src\Program.cs src\CaptureBridge.cs
 if($LASTEXITCODE -ne 0){throw 'Application compilation failed'}
 & $compiler /nologo /target:exe /platform:x64 /out:app\ContractTerminal.Capture.exe /reference:System.Web.Extensions.dll src\CaptureBridge.cs src\CaptureClient.cs
 if($LASTEXITCODE -ne 0){throw 'Capture client compilation failed'}
 $payloadFiles=@('app\www','app\ContractTerminal.exe','app\ContractTerminal.Capture.exe','app\Microsoft.Web.WebView2.Core.dll','app\Microsoft.Web.WebView2.WinForms.dll','app\WebView2Loader.dll','app\terminal.ico','app\LICENSE.txt','app\NOTICE.txt')
 Compress-Archive -Path $payloadFiles -DestinationPath payload.zip -Force
 & $compiler /nologo /target:winexe /platform:x64 /out:ContractTerminal-Setup.exe /win32icon:app\terminal.ico /win32manifest:src\app.manifest /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.IO.Compression.dll /resource:payload.zip,payload.zip src\Setup.cs
 if($LASTEXITCODE -ne 0){throw 'Installer compilation failed'}
 Write-Host 'Build complete'
} finally {Pop-Location}
