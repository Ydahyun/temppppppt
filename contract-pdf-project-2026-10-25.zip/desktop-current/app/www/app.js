'use strict';
const $ = id => document.getElementById(id);
const screenNames = {'100':'예시화면1','200':'예시화면2','300':'예시화면3','42000':'계약서통합정보 등록/조회'};
const state = {active:null, opened:[], pages:new Map(), source:[], results:[], selected:null};
const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const localDate = date => [date.getFullYear(),String(date.getMonth()+1).padStart(2,'0'),String(date.getDate()).padStart(2,'0')].join('-');
const now = new Date(), monthAgo = new Date(now.getFullYear(),now.getMonth(),now.getDate()-30);
const today = localDate(now), startDay = localDate(monthAgo);
const columns = [
 ['date','거래일자',9],['branch','계약부점',8],['id','관리번호',13],['contractStatus','계약상태',8],['approvalStatus','승인상태',8],
 ['type','계약종류',9],['name','계약건명',20],['written','계약서작성여부',9],['method','계약방식',8],['amount','계약금액',8]
];
function status(message){$('status').textContent=message;}
function selectField(label,id,options){return '<label class="filter-field"><span>'+label+'</span><select id="'+id+'">'+options.map(([value,text])=>'<option value="'+value+'">'+text+'</option>').join('')+'</select></label>';}
function detailField(label,id,extra=''){return '<label class="detail-field '+extra+'"><span>'+label+'</span><input id="'+id+'" readonly value=""></label>';}
function contractScreen(){
 return '<section id="contract-screen">'+
 '<form id="query-form" class="filter-panel">'+
 selectField('거래구분','transaction',[['query','2-조회']])+
 selectField('상태코드','contract-status',[['all','99-전체'],['정상','01-정상'],['해지','02-해지']])+
 '<label class="filter-field"><span>점번</span><input id="branch-code" class="branch-code" value="0141" aria-label="점번"><input value="영주" readonly class="branch-name" aria-label="점포명"><small>전체 9999</small></label>'+
 selectField('업무구분','business',[['all','99-전체'],['일반계약','01-일반계약'],['용역계약','02-용역계약'],['물품계약','03-물품계약']])+
 selectField('승인상태','approval-status',[['all','99-전체'],['승인','01-승인'],['진행중','02-진행중'],['반려','03-반려']])+
 '<div class="filter-field"><span>조회기간</span><div class="date-range"><input type="date" id="date-from" aria-label="조회 시작일" value="'+startDay+'" required>~<input type="date" id="date-to" aria-label="조회 종료일" value="'+today+'" required></div></div>'+
 '<div class="query-row"><span id="query-info">조회 조건을 입력한 후 조회하세요.</span><button id="query-button">F1 조회</button></div></form>'+
 '<div class="results-scroll"><table class="result-table" aria-label="계약서 조회 결과"><colgroup>'+columns.map(c=>'<col style="width:'+c[2]+'%">').join('')+'</colgroup><thead><tr>'+columns.map(c=>'<th scope="col">'+c[1]+'</th>').join('')+'</tr></thead><tbody id="results-body"></tbody></table></div>'+
 '<div class="result-count" id="result-count">0건이 조회 되었습니다.</div>'+
 '<section class="detail-panel"><div class="detail-grid">'+detailField('관리번호','detail-id')+detailField('관리부점','detail-manage')+detailField('계약부점','detail-branch')+detailField('결재승인상태','detail-approval')+detailField('계약종류','detail-type')+detailField('계약방식','detail-method')+detailField('계약서작성여부','detail-written')+detailField('전결권','detail-authority')+detailField('계약건명','detail-name','span-3')+detailField('계약금액(VAT포함)','detail-amount')+detailField('계약상대','detail-partner','span-4')+'</div></section>'+
 '<section class="detail-panel"><div class="approval-row">'+detailField('결재구분','detail-category')+'<button class="text-action" disabled>결재자 지정하기 ▣</button>'+detailField('결재선번호','detail-line')+'<button class="text-action" disabled>결재진행현황 ▣</button>'+detailField('계약체결여부','detail-complete')+'</div>'+
 '<div class="attachments">'+[1,2,3].map(n=>'<div class="attachment-row"><span>파일첨부'+n+'</span><input aria-label="파일첨부'+n+'" readonly><button disabled>첨부</button><button disabled>삭제</button><button disabled>다운</button></div>').join('')+'</div>'+
 '<div class="notes"><p>※ 계약 체결정보 등록 시 부점장님을 최종 결재권자로 지정해 주시기 바랍니다. (의뢰자→책임자→부점장)</p><p>※ 등록 후 결재 의뢰 진행하시기 바랍니다.</p></div><div class="detail-bottom"><button disabled>결재담당자 변경</button><button disabled>＋ 전송</button></div></section>'+
 '<div class="demo-tools"><span>개발용 · 등록/첨부/결재는 화면만 구현</span><button id="demo-open" type="button">테스트 데이터</button><button id="clear-data" type="button">데이터 초기화</button></div></section>';
}
function openScreen(code){
 if(!screenNames[code]){status('등록되지 않은 화면번호입니다. 100, 200, 300, 42000 중 입력하세요.');$('screen-number').focus();return;}
 if(state.active){const node=$('screen-content').firstElementChild;if(node)state.pages.set(state.active,node);}
 state.active=code;
 if(!state.opened.includes(code))state.opened.push(code);
 $('screen-tabs').innerHTML=state.opened.map(n=>'<button data-screen="'+n+'" class="'+(n===code?'active':'')+'">'+escapeHTML(screenNames[n])+' ['+n+']</button>').join('');
 $('screen-title').textContent='▣ '+screenNames[code]+' ['+code+']　★';
 $('screen-number').value=code;
 $('screen-content').replaceChildren();
 if(state.pages.has(code))$('screen-content').append(state.pages.get(code));
 else{
 $('screen-content').innerHTML=code==='42000'?contractScreen():'<section class="placeholder"><header>'+screenNames[code]+' ['+code+'] · 기능 및 내용 추가 예정</header></section>';
 if(code==='42000')bindContract();
 }
 document.querySelectorAll('.menu-tree [data-screen]').forEach(b=>b.classList.toggle('active',b.dataset.screen===code));
 $('print-open').disabled=code!=='42000';
 status('✓ '+screenNames[code]+' ['+code+'] 화면을 열었습니다.');
}
function bindContract(){
 $('query-form').addEventListener('submit',event=>{event.preventDefault();query();});
 $('demo-open').onclick=()=>$('demo-dialog').showModal();
 $('clear-data').onclick=()=>{state.source=[];state.results=[];renderResults();status('✓ 테스트 데이터와 조회 결과를 초기화했습니다.');};
 renderResults();
}
function query(){
 const from=$('date-from').value,to=$('date-to').value;
 if(!from||!to||from>to){status('조회 시작일과 종료일을 확인하세요. 시작일은 종료일보다 늦을 수 없습니다.');return;}
 const business=$('business').value, contract=$('contract-status').value, approval=$('approval-status').value, branch=$('branch-code').value.trim();
 state.results=state.source.filter(row=>row.date>=from&&row.date<=to&&(business==='all'||row.type===business)&&(contract==='all'||row.contractStatus===contract)&&(approval==='all'||row.approvalStatus===approval)&&(!branch||branch==='9999'||row.branch===branch));
 renderResults();
 $('query-info').textContent='조회 완료 · '+state.results.length.toLocaleString()+'건';
 status('✓ 거래종료 (정상처리 되었습니다.) · '+state.results.length.toLocaleString()+'건 조회');
}
function renderResults(){
 $('results-body').innerHTML=state.results.length?state.results.map((row,i)=>'<tr tabindex="0" data-row="'+i+'" aria-label="'+escapeHTML(row.id)+'">'+columns.map(([key])=>'<td>'+escapeHTML(key==='amount'?row[key].toLocaleString():row[key])+'</td>').join('')+'</tr>').join(''):'<tr><td class="empty-cell" colspan="'+columns.length+'"></td></tr>';
 $('result-count').textContent=state.results.length.toLocaleString()+'건이 조회 되었습니다.';
 $('results-body').onclick=event=>{const tr=event.target.closest('[data-row]');if(tr)chooseRow(Number(tr.dataset.row));};
 $('results-body').onkeydown=event=>{if(event.key==='Enter'){const tr=event.target.closest('[data-row]');if(tr)chooseRow(Number(tr.dataset.row));}};
 chooseRow(null);
}
function chooseRow(index){
 state.selected=index;const row=state.results[index]||{};
 const values={id:row.id,manage:row.branch,branch:row.branch,approval:row.approvalStatus,type:row.type,method:row.method,written:row.written,authority:row.id?'부점장':'',name:row.name,amount:row.amount?.toLocaleString(),partner:row.partner,category:row.id?'일반결재':'',line:row.id?'결재-'+row.id:'',complete:row.id?'Y':''};
 Object.entries(values).forEach(([key,value])=>$('detail-'+key).value=value??'');
 document.querySelectorAll('[data-row]').forEach(tr=>tr.classList.toggle('selected',Number(tr.dataset.row)===index));
}
function makeDemo(count){
 state.source=Array.from({length:count},(_,i)=>({
 date:today,branch:'0141',id:'DEMO-'+String(i+1).padStart(6,'0'),contractStatus:i%9===8?'해지':'정상',
 approvalStatus:['승인','진행중','반려'][i%3],type:['일반계약','용역계약','물품계약'][i%3],
 name:'테스트 계약 '+String(i+1).padStart(6,'0')+(i%7===0?' · 업무시스템 유지보수 및 부속 장비 공급에 관한 계약':' · 사무용품 공급'),
 written:i%4===0?'N':'Y',method:i%2?'수의계약':'경쟁입찰',amount:(i+1)*110000,partner:'가상업체 '+(i+1)
 }));
}
function openPrint(){
 if(state.active!=='42000'){status('화면 출력은 42000 화면에서 사용할 수 있습니다.');return;}
 if(document.querySelector('dialog[open]'))return;
 $('print-settings').showModal();
}
// A complete DOM snapshot, not a viewport screenshot: every result row is retained.
function buildReport(){
 const original=$('contract-screen');
 const copy=original.cloneNode(true);
 const originalControls=original.querySelectorAll('input,select');
 copy.querySelectorAll('input,select').forEach((control,index)=>{control.value=originalControls[index].value;});
 copy.querySelectorAll('.demo-tools,.query-row,.detail-bottom').forEach(node=>node.remove());
 copy.querySelectorAll('button').forEach(button=>{
 const label=document.createElement('span');label.className='printed-action';label.textContent=button.textContent;button.replaceWith(label);
 });
 copy.querySelectorAll('input,select').forEach(control=>{
 const value=document.createElement('span');value.className='printed-value';
 value.textContent=control.tagName==='SELECT'?control.selectedOptions[0]?.textContent||'':control.value;
 control.replaceWith(value);
 });
 copy.querySelectorAll('[id]').forEach(node=>node.removeAttribute('id'));
 copy.querySelectorAll('[tabindex]').forEach(node=>node.removeAttribute('tabindex'));
 const title='계약서통합정보 등록조회_42000_'+today;
 const stylesheet=new URL('styles.css',location.href).href;
 const reportCSS=`
 @page{size:A4 landscape;margin:10mm}
 :root{background:#fff!important}html,body{height:auto;min-width:0;margin:0;background:#fff;color:#223343}
 body{font-family:"Malgun Gothic","맑은 고딕",sans-serif;font-size:9pt}
 .report{max-width:277mm;margin:16px auto;padding:8px;background:white}
 .report-heading{display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid #516c85;padding-bottom:8px;margin-bottom:12px}
 .report-heading h1{font-size:14pt;margin:0}.report-heading span{font-size:8pt}
 .filter-panel{display:grid;grid-template-columns:1fr 1fr 1.8fr;padding:8px;gap:5px 12px;break-inside:avoid}
 .filter-field>span:first-child{width:55px}.filter-field{font-size:8pt}
 .printed-value{display:block;min-height:19px;flex:1;min-width:0;padding:2px 4px;border:1px solid #b5bec6;background:#f4f5f6;overflow-wrap:anywhere;white-space:pre-wrap;font-weight:400!important}
 .date-range{display:flex}.date-range .printed-value{font-size:8pt}
 .results-scroll{height:auto!important;max-height:none!important;overflow:visible!important;border:0;margin-top:10px}
 .result-table{min-width:0!important;width:100%!important;table-layout:fixed;font-size:8pt;border-collapse:collapse}
 .result-table th{position:static!important;white-space:normal;padding:5px 3px;overflow-wrap:anywhere}
 .result-table td{padding:5px 3px;white-space:normal;overflow-wrap:anywhere}
 .result-table .empty-cell{height:165px}
 thead{display:table-header-group}tbody{display:table-row-group}tr{break-inside:avoid;page-break-inside:avoid}
 .result-table tbody tr.selected{background:inherit}
 .detail-panel{break-inside:avoid;page-break-inside:avoid;margin-top:8px;padding:8px}
 .detail-grid{gap:5px 12px}.detail-field>span:first-child{font-size:8pt}
 .approval-row{gap:14px}.approval-row .detail-field{width:200px}
 .printed-action{font-size:8pt;white-space:nowrap;padding:1px 4px}
 .attachments{margin-top:24px;width:85%}.attachment-row>.printed-value{min-width:0}
 .attachment-row>span:first-child{min-width:68px}.attachment-row .printed-action{min-width:0}
 .notes{font-size:8pt}.result-count{font-size:8pt}.report-footer{font-size:8pt;margin-top:10px;color:#607080}
 @media print{
 html,body{width:auto!important;overflow:visible!important;background:#fff}
 .report{max-width:none;width:auto;margin:0;padding:0}
 *{-webkit-print-color-adjust:exact;print-color-adjust:exact}
 }
 `;
 return '<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>'+title+'</title><link rel="stylesheet" href="'+escapeHTML(stylesheet)+'"><style>'+reportCSS+'</style></head><body><article class="report"><header class="report-heading"><h1>계약서통합정보 등록/조회 [42000]</h1><span>출력일시 '+escapeHTML(new Date().toLocaleString('ko-KR'))+'</span></header>'+copy.outerHTML+'<footer class="report-footer">조회 결과 총 '+state.results.length.toLocaleString()+'건 · 현재 업무화면 전체 데이터 · 개발용 데모</footer></article></body></html>';
}
async function printFrame(){
 const frame=$('print-frame');await frame.contentDocument.fonts.ready;
 if(window.chrome && window.chrome.webview){
   window.chrome.webview.postMessage({type:'print',html:frame.srcdoc});
   return;
 }
 frame.contentWindow.focus();frame.contentWindow.print();
}
function showPreview(){
 $('print-warning').close();$('print-settings').close();
 $('preview-count').textContent='조회 결과 '+state.results.length.toLocaleString()+'건';
 $('print-preview').showModal();
 $('print-again').disabled=true;
 $('print-frame').onload=async()=>{
  $('print-again').disabled=false;
  try{await printFrame();}catch(error){status('인쇄 / PDF 저장 버튼을 눌러 인쇄창을 열어 주세요.');}
 };
 $('print-frame').srcdoc=buildReport();
}
$('screen-search').onsubmit=event=>{event.preventDefault();openScreen($('screen-number').value.trim());};
document.addEventListener('click',event=>{
 const screen=event.target.closest('[data-screen]');if(screen)openScreen(screen.dataset.screen);
 const close=event.target.closest('[data-close]');if(close)$(close.dataset.close).close();
});
$('collapse-tree').onclick=()=>document.querySelectorAll('.menu-tree details').forEach(d=>d.open=false);
$('expand-tree').onclick=()=>document.querySelectorAll('.menu-tree details').forEach(d=>d.open=true);
$('print-open').onclick=openPrint;
$('settings-confirm').onclick=()=>$('print-warning').showModal();
$('warning-confirm').onclick=showPreview;
$('print-again').onclick=printFrame;
$('demo-form').onsubmit=event=>{
 event.preventDefault();const count=Number($('demo-count').value);
 if(!Number.isInteger(count)||count<0||count>2000)return;
 makeDemo(count);$('demo-dialog').close();
 $('date-from').value=startDay;$('date-to').value=today;$('branch-code').value='0141';
 ['business','contract-status','approval-status'].forEach(id=>$(id).value='all');
 status('✓ 가상 데이터 '+count.toLocaleString()+'건 준비 완료. F1 또는 조회를 누르세요.');
};
document.addEventListener('keydown',event=>{
 if(event.ctrlKey&&event.key==='F3'){event.preventDefault();openPrint();}
 if(event.key==='F1'&&state.active==='42000'&&!document.querySelector('dialog[open]')){event.preventDefault();$('query-form').requestSubmit();}
});
openScreen('42000');


