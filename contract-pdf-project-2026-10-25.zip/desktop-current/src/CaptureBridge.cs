using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
internal static class CaptureBridge {
 static readonly string Folder=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Bridge");
 static string Session;
 public static int RunClient(){
  string requestPath=null,responsePath=null;
  try {
   var json=new JavaScriptSerializer();
   var endpoint=json.Deserialize<Endpoint>(File.ReadAllText(Path.Combine(Folder,"endpoint.json")));
   if(endpoint==null||String.IsNullOrEmpty(endpoint.session))throw new Exception("No endpoint");
   string id=Guid.NewGuid().ToString("N");
   requestPath=Path.Combine(Folder,id+".request");responsePath=Path.Combine(Folder,id+".response");
   string temp=requestPath+".tmp";
   File.WriteAllText(temp,json.Serialize(new Request{operation="capture",screen=42000,session=endpoint.session}),new UTF8Encoding(false));File.Move(temp,requestPath);
   DateTime limit=DateTime.UtcNow.AddSeconds(95);
   while(!File.Exists(responsePath)&&DateTime.UtcNow<limit)Thread.Sleep(150);
   if(!File.Exists(responsePath))throw new TimeoutException();
   Console.OutputEncoding=new UTF8Encoding(false);Console.WriteLine(File.ReadAllText(responsePath));return 0;
  } catch(Exception) {Console.OutputEncoding=new UTF8Encoding(false);Console.WriteLine("{\"ok\":false,\"error\":\"통합단말을 실행한 뒤 다시 요청하세요. 실행 중이라면 MCP 연동 버전인지 확인하세요.\"}");return 1;}
  finally{try{if(requestPath!=null&&File.Exists(requestPath))File.Delete(requestPath);if(responsePath!=null&&File.Exists(responsePath))File.Delete(responsePath);}catch{}}
 }
 public static void Start(Func<Task<object>> capture){
  Directory.CreateDirectory(Folder);Session=Guid.NewGuid().ToString("N");
  File.WriteAllText(Path.Combine(Folder,"endpoint.json"),new JavaScriptSerializer().Serialize(new Endpoint{session=Session}),new UTF8Encoding(false));
  Task.Factory.StartNew(()=>{
   var json=new JavaScriptSerializer();
   while(true){
    try{
     foreach(string file in Directory.GetFiles(Folder,"*.request")){
      if(DateTime.UtcNow-File.GetLastWriteTimeUtc(file)>TimeSpan.FromMinutes(2)){File.Delete(file);continue;}
      var req=json.Deserialize<Request>(File.ReadAllText(file));
      object result;
      if(req==null||req.operation!="capture"||req.screen!=42000||req.session!=Session)result=new{ok=false,error="오래되었거나 지원하지 않는 요청입니다. 다시 요청하세요."};
      else {try{result=capture().GetAwaiter().GetResult();}catch(Exception ex){result=new{ok=false,error=ex.Message};}}
      string dest=Path.ChangeExtension(file,".response"),temp=dest+".tmp";
      File.WriteAllText(temp,json.Serialize(result),new UTF8Encoding(false));File.Move(temp,dest);File.Delete(file);
     }
    }catch{}
    Thread.Sleep(100);
   }
  },TaskCreationOptions.LongRunning);
 }
 class Request {public string operation{get;set;}public int screen{get;set;}public string session{get;set;}}
 class Endpoint{public string session{get;set;}}
}
