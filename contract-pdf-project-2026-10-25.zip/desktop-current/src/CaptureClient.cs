internal static class CaptureClient { static int Main(){return CaptureBridge.RunClient();} }
