using System;
using System.IO;
using System.Drawing;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

internal static class Program
{
    public static readonly string Root = AppDomain.CurrentDomain.BaseDirectory;
    public static string TestDirectory;
    public static bool BridgeTest;
    [STAThread] static void Main(string[] args)
    {
        if(args.Length==1 && args[0]=="--capture-json"){System.Environment.ExitCode=CaptureBridge.RunClient();return;}
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        if (args.Length == 2 && args[0] == "--self-test") TestDirectory = Path.GetFullPath(args[1]);
        if(args.Length==2 && args[0]=="--bridge-test"){TestDirectory=Path.GetFullPath(args[1]);BridgeTest=true;Directory.CreateDirectory(TestDirectory);}
        Application.Run(new TerminalForm());
    }
    public static Icon AppIcon() { return Icon.ExtractAssociatedIcon(Application.ExecutablePath); }
    public static async Task<CoreWebView2Environment> EnvironmentAsync()
    {
        string profile = TestDirectory != null ? Path.Combine(TestDirectory,"profile") : Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData),"ContractTerminal","WebView2");
        Directory.CreateDirectory(profile);
        return await CoreWebView2Environment.CreateAsync(null, profile);
    }
    public static void Configure(WebView2 view, bool allowReportDocument = false)
    {
        view.CoreWebView2.SetVirtualHostNameToFolderMapping("terminal.internal", Path.Combine(Root,"www"), CoreWebView2HostResourceAccessKind.DenyCors);
        view.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;
        view.CoreWebView2.Settings.IsStatusBarEnabled = false;
        view.CoreWebView2.Settings.AreDevToolsEnabled = false;
        view.CoreWebView2.Settings.IsZoomControlEnabled = true;
        view.CoreWebView2.NewWindowRequested += (s,e) => { e.Handled=true; };
        view.CoreWebView2.PermissionRequested += (s,e) => {e.State=CoreWebView2PermissionState.Deny;};
        view.CoreWebView2.NavigationStarting += (s,e) => {
            Uri uri;
            if(Program.TestDirectory!=null)File.AppendAllText(Path.Combine(Program.TestDirectory,"navigation.txt"),e.Uri.Substring(0,Math.Min(e.Uri.Length,100))+"\n");
            if (e.Uri=="about:blank" || (allowReportDocument && e.Uri.StartsWith("data:text/html;charset=utf-8;base64,",StringComparison.Ordinal))) return;
            if (!Uri.TryCreate(e.Uri,UriKind.Absolute,out uri) || uri.Scheme!="https" || uri.Host!="terminal.internal") e.Cancel=true;
        };
    }
}
internal class TerminalForm : Form
{
    readonly WebView2 view = new WebView2();
    CoreWebView2Environment environment;
    ReportForm report;
    readonly JavaScriptSerializer json = new JavaScriptSerializer {MaxJsonLength=16*1024*1024};
    public TerminalForm()
    {
        Text="계약서 통합단말";Icon=Program.AppIcon();Size=new Size(1550,980);MinimumSize=new Size(1180,780);
        StartPosition=FormStartPosition.CenterScreen;WindowState=FormWindowState.Maximized;
        view.Dock=DockStyle.Fill;Controls.Add(view);
        if (Program.TestDirectory!=null) {Opacity=0;ShowInTaskbar=false;WindowState=FormWindowState.Normal;}
        Shown+=async(s,e)=>await InitializeAsync();
    }
    async Task InitializeAsync()
    {
        try
        {
            environment=await Program.EnvironmentAsync();
            await view.EnsureCoreWebView2Async(environment);
            Program.Configure(view);
            view.CoreWebView2.WebMessageReceived+=async(s,e)=>{
                try {
                    if(e.Source!="https://terminal.internal/index.html")return;
                    var message=json.Deserialize<PrintMessage>(e.WebMessageAsJson);
                    if(message==null||message.type!="print"||String.IsNullOrEmpty(message.html))return;
                    if(report!=null&&!report.IsDisposed){report.Activate();return;}
                    report=new ReportForm(environment,message.html,false);
                    report.Show(this);
                    await report.LoadReportAsync();
                    report.OpenPrintUI();
                } catch(Exception ex) {MessageBox.Show(this,"출력 창을 열지 못했습니다.\n"+ex.Message,"출력 오류",MessageBoxButtons.OK,MessageBoxIcon.Error);}
            };
            var loaded=new TaskCompletionSource<bool>();
            view.CoreWebView2.NavigationCompleted+=(s,e)=>loaded.TrySetResult(e.IsSuccess);
            view.CoreWebView2.Navigate("https://terminal.internal/index.html");
            if(!await loaded.Task)throw new Exception("업무화면을 불러오지 못했습니다.");
            if(Program.BridgeTest)await view.ExecuteScriptAsync("makeDemo(120);query();chooseRow(0);");
            if(Program.TestDirectory==null||Program.BridgeTest)CaptureBridge.Start(CaptureOnUiThread);
            if(Program.BridgeTest)File.WriteAllText(Path.Combine(Program.TestDirectory,"READY.txt"),"ready");
            if(Program.TestDirectory!=null&&!Program.BridgeTest)await SelfTestAsync();
        }
        catch(Exception ex)
        {
            if(Program.TestDirectory!=null) {Directory.CreateDirectory(Program.TestDirectory);File.WriteAllText(Path.Combine(Program.TestDirectory,"FAILED.txt"),ex.ToString());Close();return;}
            MessageBox.Show(this,"프로그램 초기화에 실패했습니다.\n\n"+ex.Message+"\n\nMicrosoft Edge WebView2 Runtime 설치 여부와 www 폴더를 확인하세요.\n공식 설치 안내: https://developer.microsoft.com/microsoft-edge/webview2/","실행 오류",MessageBoxButtons.OK,MessageBoxIcon.Error);
            Close();
        }
    }
    bool captureBusy;
    Task<object> CaptureOnUiThread()
    {
        var completion=new TaskCompletionSource<object>();
        BeginInvoke(new Action(async ()=>{
            if(captureBusy){completion.SetResult(new{ok=false,error="다른 PDF를 생성하고 있습니다. 잠시 후 다시 요청하세요."});return;}
            captureBusy=true;
            ReportForm export=null;
            try {
                string screen=await view.ExecuteScriptAsync("openScreen('42000'); JSON.stringify({rows:state.results.length})");
                var info=json.Deserialize<System.Collections.Generic.Dictionary<string,object>>(json.Deserialize<string>(screen));
                string html=json.Deserialize<string>(await view.ExecuteScriptAsync("buildReport()"));
                string folder=Path.Combine(Program.Root,"Exports");Directory.CreateDirectory(folder);
                string filename="계약서통합정보_42000_"+DateTime.Now.ToString("yyyyMMdd_HHmmss")+"_"+Guid.NewGuid().ToString("N").Substring(0,8)+".pdf";
                string output=Path.Combine(folder,filename);
                export=new ReportForm(environment,html,true);
                export.Show(this);await export.LoadReportAsync();await export.SavePdfAsync(output);
                completion.SetResult(new{ok=true,path=output,filename=filename,screen=42000,rows=Convert.ToInt32(info["rows"])});
            }catch(Exception ex){completion.SetResult(new{ok=false,error=ex.Message});}
            finally{if(export!=null)export.Close();captureBusy=false;}
        }));
        return completion.Task;
    }

    async Task SelfTestAsync()
    {
        Directory.CreateDirectory(Program.TestDirectory);
        string result=await view.ExecuteScriptAsync(@"(()=>{
            const checks=[];
            for(const code of ['100','200','300','42000']){openScreen(code);if(state.active!==code)throw Error('screen');checks.push(code);}
            makeDemo(120);query();
            if(state.results.length!==120)throw Error('rows');
            chooseRow(0);
            return {screens:checks,rows:state.results.length,title:document.title};
        })()");
        File.WriteAllText(Path.Combine(Program.TestDirectory,"ui-checks.json"),result);
        using(var image=File.Create(Path.Combine(Program.TestDirectory,"desktop-screen.png")))
            await view.CoreWebView2.CapturePreviewAsync(CoreWebView2CapturePreviewImageFormat.Png,image);
        string html=json.Deserialize<string>(await view.ExecuteScriptAsync("buildReport()"));
        var testReport=new ReportForm(environment,html,true);
        testReport.Show(this);await testReport.LoadReportAsync();
        await testReport.SavePdfAsync(Path.Combine(Program.TestDirectory,"desktop-120-records.pdf"));
        string width=await testReport.View.ExecuteScriptAsync("JSON.stringify({rows:document.querySelectorAll('tbody tr').length, width:document.querySelector('.result-table').scrollWidth, text:document.body.innerText.includes('DEMO-000120')})");
        File.WriteAllText(Path.Combine(Program.TestDirectory,"report-checks.json"),width);
        testReport.Close();
        await view.ExecuteScriptAsync("$('approval-status').value='승인';query();");
        string filtered=json.Deserialize<string>(await view.ExecuteScriptAsync("buildReport()"));
        var filteredReport=new ReportForm(environment,filtered,true);
        filteredReport.Show(this);await filteredReport.LoadReportAsync();
        await filteredReport.SavePdfAsync(Path.Combine(Program.TestDirectory,"desktop-filtered.pdf"));
        filteredReport.Close();
        File.WriteAllText(Path.Combine(Program.TestDirectory,"PASS.txt"),"WebView2 startup, screen switching, 120-row query, full PDF export and filtered PDF export completed.");
        Close();
    }
    class PrintMessage { public string type {get;set;} public string html {get;set;} }
}
internal class ReportForm : Form
{
    public readonly WebView2 View=new WebView2();
    readonly CoreWebView2Environment environment;
    readonly string html;
    readonly Button print=new Button {Text="인쇄 / PDF 저장",AutoSize=true,Enabled=false};
    readonly Button save=new Button {Text="PDF 파일로 저장",AutoSize=true,Enabled=false};
    public ReportForm(CoreWebView2Environment environment,string html,bool testing)
    {
        this.environment=environment;this.html=html;
        Text="현재 화면 출력 - 계약서 통합단말";Icon=Program.AppIcon();
        Size=new Size(1280,900);MinimumSize=new Size(900,650);StartPosition=FormStartPosition.CenterParent;
        View.Dock=DockStyle.Fill;
        var toolbar=new FlowLayoutPanel {Dock=DockStyle.Top,Height=47,Padding=new Padding(10,8,0,0),BackColor=Color.FromArgb(232,237,242)};
        toolbar.Controls.Add(new Label{Text="조회 결과 전체가 여러 페이지로 출력됩니다.",AutoSize=true,Padding=new Padding(0,5,18,0)});
        toolbar.Controls.Add(print);toolbar.Controls.Add(save);
        var close=new Button{Text="닫기",AutoSize=true};close.Click+=(s,e)=>Close();toolbar.Controls.Add(close);
        Controls.Add(View);Controls.Add(toolbar);
        print.Click+=(s,e)=>OpenPrintUI();
        save.Click+=async(s,e)=>await ChoosePdfAsync();
        if(testing){Opacity=0;ShowInTaskbar=false;}
    }
    public async Task LoadReportAsync()
    {
        await View.EnsureCoreWebView2Async(environment);Program.Configure(View,true);
        var ready=new TaskCompletionSource<bool>();
        View.CoreWebView2.NavigationCompleted+=(s,e)=>ready.TrySetResult(e.IsSuccess);
        View.NavigateToString(html);
        if(!await ready.Task)throw new Exception("출력 문서를 불러오지 못했습니다.");
        await View.ExecuteScriptAsync("document.fonts.ready.then(()=>true)");
        print.Enabled=true;save.Enabled=true;
    }
    public void OpenPrintUI()
    {
        if(View.CoreWebView2==null)return;
        try{View.CoreWebView2.ShowPrintUI(CoreWebView2PrintDialogKind.Browser);}
        catch(Exception ex){MessageBox.Show(this,"인쇄창을 열지 못했습니다. PDF 파일로 저장 버튼을 이용해 주세요.\n"+ex.Message);}
    }
    public async Task SavePdfAsync(string filename)
    {
        var settings=environment.CreatePrintSettings();
        settings.Orientation=CoreWebView2PrintOrientation.Landscape;
        settings.PageWidth=8.2677;settings.PageHeight=11.6929;
        settings.MarginTop=0.3937;settings.MarginBottom=0.3937;settings.MarginLeft=0.3937;settings.MarginRight=0.3937;
        settings.ShouldPrintBackgrounds=true;settings.ShouldPrintHeaderAndFooter=false;
        if(!await View.CoreWebView2.PrintToPdfAsync(filename,settings))throw new Exception("PDF 저장에 실패했습니다.");
    }
    async Task ChoosePdfAsync()
    {
        using(var dialog=new SaveFileDialog{Filter="PDF 문서 (*.pdf)|*.pdf",DefaultExt="pdf",AddExtension=true,OverwritePrompt=true,FileName="계약서통합정보_42000_"+DateTime.Now.ToString("yyyyMMdd_HHmmss")+".pdf"})
        {
            if(dialog.ShowDialog(this)!=DialogResult.OK)return;
            try {
                save.Enabled=false;print.Enabled=false;
                await SavePdfAsync(dialog.FileName);
                MessageBox.Show(this,"PDF 저장을 완료했습니다.\n"+dialog.FileName,"저장 완료",MessageBoxButtons.OK,MessageBoxIcon.Information);
            } catch(Exception ex) {MessageBox.Show(this,ex.Message,"PDF 저장 오류",MessageBoxButtons.OK,MessageBoxIcon.Error);}
            finally {save.Enabled=true;print.Enabled=true;}
        }
    }
}

