using System;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Diagnostics;
using System.Windows.Forms;
internal static class Setup {
 [STAThread] static void Main(string[] args) {
  Application.EnableVisualStyles();
  string target=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Programs","ContractTerminal");
  string desktop=Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
  bool silent=false;
  for(int i=0;i<args.Length;i++){
   if(args[i]=="--silent")silent=true;
   else if(args[i]=="--target"&&i+1<args.Length)target=Path.GetFullPath(args[++i]);
   else if(args[i]=="--shortcut-dir"&&i+1<args.Length)desktop=Path.GetFullPath(args[++i]);
  }
  if(!silent&&MessageBox.Show("계약서 통합단말을 설치하고 바탕화면에 실행 아이콘을 만듭니다.\n\n설치 위치: "+target+"\n\n설치할까요?","계약서 통합단말 설치",MessageBoxButtons.OKCancel,MessageBoxIcon.Information)!=DialogResult.OK)return;
  try {
   Directory.CreateDirectory(target);
   using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("payload.zip"))
   using(var zip=new ZipArchive(stream,ZipArchiveMode.Read))
   foreach(var entry in zip.Entries){
    if(String.IsNullOrEmpty(entry.Name))continue;
    string destination=Path.GetFullPath(Path.Combine(target,entry.FullName));
    if(!destination.StartsWith(Path.GetFullPath(target)+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase))throw new Exception("잘못된 설치 파일 경로");
    Directory.CreateDirectory(Path.GetDirectoryName(destination));
    using(var input=entry.Open())
    using(var output=new FileStream(destination,FileMode.Create,FileAccess.Write))input.CopyTo(output);
   }
   Directory.CreateDirectory(desktop);
   var shellType=Type.GetTypeFromProgID("WScript.Shell");
   object shell=Activator.CreateInstance(shellType);
   object link=shellType.InvokeMember("CreateShortcut",BindingFlags.InvokeMethod,null,shell,new object[]{Path.Combine(desktop,"계약서 통합단말.lnk")});
   var type=link.GetType();
   type.InvokeMember("TargetPath",BindingFlags.SetProperty,null,link,new object[]{Path.Combine(target,"ContractTerminal.exe")});
   type.InvokeMember("WorkingDirectory",BindingFlags.SetProperty,null,link,new object[]{target});
   type.InvokeMember("IconLocation",BindingFlags.SetProperty,null,link,new object[]{Path.Combine(target,"ContractTerminal.exe")+",0"});
   type.InvokeMember("Description",BindingFlags.SetProperty,null,link,new object[]{"계약서 조회 및 전체 데이터 PDF 출력"});
   type.InvokeMember("Save",BindingFlags.InvokeMethod,null,link,null);
   System.Runtime.InteropServices.Marshal.FinalReleaseComObject(link);
   System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shell);
   if(!silent&&MessageBox.Show("설치를 완료했습니다. 바탕화면 아이콘으로 실행할 수 있습니다.\n\n지금 실행할까요?","설치 완료",MessageBoxButtons.YesNo,MessageBoxIcon.Information)==DialogResult.Yes)
    Process.Start(new ProcessStartInfo(Path.Combine(target,"ContractTerminal.exe")){UseShellExecute=true,WorkingDirectory=target});
  } catch(Exception ex) {
   if(silent){Console.Error.WriteLine(ex);Environment.ExitCode=1;}
   else MessageBox.Show("설치에 실패했습니다. 실행 중인 통합단말을 닫은 뒤 다시 시도하세요.\n\n"+ex.Message,"설치 오류",MessageBoxButtons.OK,MessageBoxIcon.Error);
  }
 }
}