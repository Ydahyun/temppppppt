const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const files = {'/':'index.html','/index.html':'index.html','/app.js':'app.js','/styles.css':'styles.css'};
const types = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8'};
const port = Number(process.env.PORT || 3000);
http.createServer((req,res)=>{
 const name=files[new URL(req.url,'http://localhost').pathname];
 if(!name){res.writeHead(404);res.end('Not found');return;}
 fs.readFile(path.join(__dirname,name),(error,data)=>{
 if(error){res.writeHead(500);res.end('File read failed');return;}
 res.writeHead(200,{'Content-Type':types[path.extname(name)],'Cache-Control':'no-store'});res.end(data);
 });
}).listen(port,'127.0.0.1',()=>console.log('실행 중: http://localhost:'+port+'\n종료: Ctrl+C')).on('error',e=>{console.error(e.code==='EADDRINUSE'?'포트 사용 중: 다른 서버를 종료하거나 PORT를 변경하세요.':e.message);process.exitCode=1;});

